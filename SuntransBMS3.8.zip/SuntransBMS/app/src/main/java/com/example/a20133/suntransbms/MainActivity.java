package com.example.a20133.suntransbms;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;

import Subtrans.slidingmenu.view.SlidingMenu;

public class MainActivity extends FragmentActivity implements View.OnClickListener{

    private  LinearLayout mTabforecast;
    private  LinearLayout mTabcharge;
    private  LinearLayout mTabdischarge;
    private  LinearLayout mTabsetting;

    private ImageButton mImgforecast;
    private ImageButton mImgcharge;
    private ImageButton mImgdischarge;
    private ImageButton mImgsetting;

    private TextView mTvforecast;
    private TextView mTvcharge;
    private TextView mTvdischarge;
    private TextView mTvsetting;

    private Fragment mFgforecast;
    private Fragment mFgcharge;
    private Fragment mFgdischarge;
    private Fragment mFgsetting;

    /*
    * 以下是侧滑菜单定义属性*/
    private SlidingMenu mLeftMenu;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();

        initEvent();

        setSelect(0);

        mLeftMenu = (SlidingMenu) findViewById(R.id.id_menu);


    }

    private void initEvent() {

        mTabforecast.setOnClickListener(this);
        mTabcharge.setOnClickListener(this);
        mTabdischarge.setOnClickListener(this);
        mTabsetting.setOnClickListener(this);

    }

    private void initView() {

        mTabforecast = (LinearLayout) findViewById(R.id.id_mTabforecast);
        mTabcharge = (LinearLayout) findViewById(R.id.id_mTabcharge);
        mTabdischarge = (LinearLayout) findViewById(R.id.id_mTabdischarge);
        mTabsetting = (LinearLayout) findViewById(R.id.id_mTabsetting);

        mImgforecast = (ImageButton) findViewById(R.id.id_mImgforecast);
        mImgcharge = (ImageButton) findViewById(R.id.id_mImgcharge);
        mImgdischarge = (ImageButton) findViewById(R.id.id_mImgdischarge);
        mImgsetting = (ImageButton) findViewById(R.id.id_mImgsetting);

        mTvforecast = (TextView)findViewById(R.id.id_mTvforcast);
        mTvcharge = (TextView)findViewById(R.id.id_mTvcharge);
        mTvdischarge = (TextView)findViewById(R.id.id_mTvdischarge);
        mTvsetting = (TextView)findViewById(R.id.id_mTvsetting);



    }


    private void setSelect(int i){

        FragmentManager fm = getSupportFragmentManager();
        FragmentTransaction transaction = fm.beginTransaction();

        hideFragment(transaction);

        switch (i) {

            case 0:
                if(mFgforecast==null){
                    mFgforecast = new ForecastFragment();
                    transaction.add(R.id.id_Flcontent,mFgforecast);
                }else {
                    transaction.show(mFgforecast);
                }
                mImgforecast.setImageResource(R.drawable.whuxy6);
                mTvforecast.setTextColor(0xff11c8a7);
                break;
            case 1:
               if(mFgcharge==null){
                    mFgcharge = new ChargeFragment();
                    transaction.add(R.id.id_Flcontent,mFgcharge);
                }else {
                    transaction.show(mFgcharge);
                }
                mImgcharge.setImageResource(R.drawable.whuxy6);
                mTvcharge.setTextColor(0xff11c8a7);
                break;
            case 2:
                if(mFgdischarge==null){
                    mFgdischarge = new DischargeFragment();
                    transaction.add(R.id.id_Flcontent,mFgdischarge);
                }else {
                    transaction.show(mFgdischarge);
                }
                mImgdischarge.setImageResource(R.drawable.whuxy6);
                mTvdischarge.setTextColor(0xff11c8a7);
                break;
            case 3:
                if(mFgsetting==null){
                    mFgsetting = new SettingFragment();
                    transaction.add(R.id.id_Flcontent,mFgsetting);
                }else {
                    transaction.show(mFgsetting);
                }
                mImgsetting.setImageResource(R.drawable.whuxy6);
                mTvsetting.setTextColor(0xff11c8a7);
                break;


        }
        transaction.commit();

    }

    private void hideFragment(FragmentTransaction transaction) {

        if(mFgforecast!=null){
            transaction.hide(mFgforecast);
        }
        if(mFgcharge!=null){
            transaction.hide(mFgcharge);
        }
        if(mFgdischarge!=null){
            transaction.hide(mFgdischarge);
        }
        if(mFgsetting!=null){
            transaction.hide(mFgsetting);
        }
    }


    @Override
    public void onClick(View v) {

        resetAllTab();

        switch (v.getId()){

            case R.id.id_mTabforecast:
                setSelect(0);

              break;
            case R.id.id_mTabcharge:
                setSelect(1);

              break;
            case R.id.id_mTabdischarge:
                setSelect(2);

               break;
            case R.id.id_mTabsetting:
                setSelect(3);

              break;

        }

    }

    private void resetAllTab() {

        mImgforecast.setImageResource(R.drawable.whuxy1);
        mImgcharge.setImageResource(R.drawable.whuxy1);
        mImgdischarge.setImageResource(R.drawable.whuxy1);
        mImgsetting.setImageResource(R.drawable.whuxy1);


        mTvforecast.setTextColor(0xff646565);
        mTvcharge.setTextColor(0xff646565);
        mTvdischarge.setTextColor(0xff646565);
        mTvsetting.setTextColor(0xff646565);
    }
    public void toggleMenu(View view){

        mLeftMenu.toggle();
    }
    @Override
    public boolean onCreatePanelMenu(int featureId, Menu menu) {
        getMenuInflater().inflate(R.menu.main,menu);

        return true;
    }
}
